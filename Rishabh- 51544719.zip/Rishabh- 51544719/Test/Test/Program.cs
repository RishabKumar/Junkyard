﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Test.CacheCollection;

namespace Test
{
    class Program
    {
        private static CacheSet cache;
        private const string cachepath = @"F:\Collaborative Engineering - Hands-On\Rishabh- 51544719\cache\cache.txt";



        static void Main(string[] args)
        {

            using (cache = new CacheSet(2))
            {
                //     ReloadCache();
                AddToCache();
                while (true)
                {
                    Console.WriteLine("Search term ? ");
                    string url = Console.ReadLine().ToLowerInvariant();
                    if (string.IsNullOrWhiteSpace(url))
                    {
                        return;
                    }
                    FindInCache(url);
                }
            }
        }

        static void FindInCache(string url)
        {
            if (cache.LookUp(url))
            {
                Console.WriteLine("Found");
            }
            else
            {
                Console.WriteLine("Not Found");
            }
        }

        static void AddToCache()
        {
            var list = new string[] {"",
                "https://github.com/RishabKumar",
                "https://github.com/",
                "https://github.com/1/2/3",
                "https://github.com/a/b/c",
                "https://github.com/q/w/e",
                "https://github.com/a/s/d",
                "https://github.com/z/x/c",
                "https://github.com/qwerty/1/2",
                "https://github.com/sdf/sdf/sdf",
                "https://github.com/tert/asf/rtd",
                "https://github.com/234/324/324",
                "https://github.com/htr/asf/ry",
                "https://github.com/4r/dd/3d3q/3",
                "https://github.com/ad/fwe",
                "https://github.com/a/q/z/a",
                "https://github.com/q/w",
                "https://github.com/zxa/as",
                "https://github.com/asd",
                "https://github.com/mfsj",
                "https://github.com/23d/d34d",
                "https://github.com/asdf-asd/asd3",
                "https://github.com/ad-ada",
                "https://github.com/1",
                "https://github.com/2",
                "https://github.com/3"};
            foreach(var f in list)
            {
                var tmp = f.ToLowerInvariant();
         //       Console.WriteLine("Adding to cache: " + tmp);
                cache.Add(tmp);   
            }
            
        }

        static void ReloadCache()
        {
            cache = new CacheSet(50);
            if (File.Exists(cachepath))
            {
                foreach (var entry in File.ReadLines(cachepath))
                {
                    cache.Add(entry);
                }
            }
        }
    }
}
