﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Web;

namespace Test.CacheCollection
{
    class CacheSet : ConcurrentDictionary<string, int>, IDisposable
    {
        private readonly int _cachesize;
        private const string _cachepath = @"F:\Collaborative Engineering - Hands-On\Rishabh- 51544719\cache";
        private ConcurrentDictionary<string, int> _cacheDic;

        public CacheSet(int size = 2) : base()
        {
            _cachesize = size;
            _cacheDic = new ConcurrentDictionary<string, int>();
            LoadCache();
        }

        public int Count
        {
            get { return _cacheDic.Count; }
        }

        private void LoadCache(string cachepath = _cachepath)
        {
            foreach(var file in Directory.EnumerateFiles(cachepath))
            {
                Add(HttpUtility.UrlDecode(Path.GetFileName(file)), Int32.Parse(File.ReadAllLines(file)[0]));
            }
        }

        public bool Add(string item, int count = 1)
        {
            if (!string.IsNullOrWhiteSpace(item))
            {
                if (this.Count < _cachesize)
                {
                    _cacheDic.GetOrAdd(item, count);
                    var timer = new CacheTimer(item, 500000);
                    timer.Elapsed += new ElapsedEventHandler(Elapsed_Event);
                    timer.Start();
                    return true;
                }
                else
                {
                    if (PerformLFU(item, count) > -1)
                    {
                        
                    }
                    else
                    {
                        WriteToDisk(item, count);
                    }
                }
            }
            return false;
        }

        private void WriteToDisk(string item, int count)
        {
            if(!string.IsNullOrWhiteSpace(item))
                File.WriteAllText(_cachepath + "/" + HttpUtility.UrlEncode(item), count.ToString());
        }

        private int PerformLFU(string key = "", int value = -1)
        {
            int i = -1;
            var pair =_cacheDic.OrderBy(x=>x.Value).FirstOrDefault();
            //check <value first and then <2
            if (pair.Value < value || pair.Value < 2)
            {
                _cacheDic.TryRemove(pair.Key, out i);
                if(i > -1) // has been removed condition, add to new key to cache and add removed key to disk.
                {
                    WriteToDisk(pair.Key, pair.Value);
                    Add(key, value);
                }
            }
            else
            {
                if(!string.IsNullOrWhiteSpace(key))
                {
                    WriteToDisk(key, value);
                }
            }
            return i;
        }

        public bool LookUp(string item)
        {
            if (_cacheDic.ContainsKey(item))
            {
                _cacheDic[item] += 1; 
                return true;
            }
            return DeepLookUp(item);
        }

        private bool DeepLookUp(string item)
        {
            var file = HttpUtility.UrlEncode(item);
            var filepath = _cachepath + "/" + file;
            if (File.Exists(filepath))
            {
                int count = Int32.Parse(File.ReadAllLines(filepath)[0]) + 1;
                WriteToDisk(item, count);
                PerformLFU(item, count);
                return true;
            }
            else
            {
                return false;
            }
        }

        public void Dispose()
        {
            for(int i = 0; i < this.Count; i++)
            {
                var keyvaluepair = _cacheDic.ElementAt(i);
                WriteToDisk(keyvaluepair.Key, keyvaluepair.Value);
            }
        }

        private void Elapsed_Event(object sender, ElapsedEventArgs e)
        {
            int i = 0;
            var cachetimer = (CacheTimer)sender;
            cachetimer.Elapsed -= new ElapsedEventHandler(Elapsed_Event);
            _cacheDic.TryRemove(cachetimer.key, out i);
        }
    }

    public class CacheTimer : Timer
    {
        public string key {get; set; }
        public CacheTimer(string key, double interval) : base(interval)
        {
            this.key = key;
        }
    }
}
